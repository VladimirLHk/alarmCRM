'use strict'

define([], function () {
  /**
   * Какой-то модуль
   * @param {string} text
   */
  var widgetHelper = function (text) {
    console.log(text)
  }

  return widgetHelper
});

